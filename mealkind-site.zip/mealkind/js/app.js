// ── LANGUAGE STRINGS ──────────────────────────────────────────
const STRINGS = {
  en: {
    nav_patient:    "I'm a Patient",
    nav_caregiver:  "I Want to Help",
    nav_recipes:    "Recipes",
    nav_calendar:   "My Calendar",
    nav_signin:     "Sign In",
    required:       "This field is required.",
    invalid_email:  "Please enter a valid email address.",
    invalid_zip:    "Please enter a valid 5-digit ZIP code.",
    invalid_phone:  "Please enter a valid phone number.",
    submitting:     "Submitting…",
    submit_error:   "Something went wrong. Please try again.",
  },
  es: {
    nav_patient:    "Soy Paciente",
    nav_caregiver:  "Quiero Ayudar",
    nav_recipes:    "Recetas",
    nav_calendar:   "Mi Calendario",
    nav_signin:     "Iniciar Sesión",
    required:       "Este campo es obligatorio.",
    invalid_email:  "Ingresa un correo electrónico válido.",
    invalid_zip:    "Ingresa un código postal de 5 dígitos.",
    invalid_phone:  "Ingresa un número de teléfono válido.",
    submitting:     "Enviando…",
    submit_error:   "Algo salió mal. Por favor intenta de nuevo.",
  }
};

// ── LANGUAGE TOGGLE ──────────────────────────────────────────
let currentLang = localStorage.getItem('mk_lang') || 'en';

function setLang(lang) {
  currentLang = lang;
  localStorage.setItem('mk_lang', lang);
  document.documentElement.setAttribute('lang', lang);

  // Update toggle buttons
  document.querySelectorAll('.lang-toggle button').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.lang === lang);
  });

  // Swap visible text elements
  document.querySelectorAll('[data-en]').forEach(el => {
    el.textContent = el.dataset[lang] || el.dataset.en;
  });

  // Swap placeholders
  document.querySelectorAll('[data-placeholder-en]').forEach(el => {
    el.placeholder = el.dataset[`placeholder${lang.charAt(0).toUpperCase()+lang.slice(1)}`]
                   || el.dataset.placeholderEn;
  });
}

function initLangToggle() {
  document.querySelectorAll('.lang-toggle button').forEach(btn => {
    btn.addEventListener('click', () => setLang(btn.dataset.lang));
  });
  setLang(currentLang);
}

// ── DIETARY TAG FILTERS ──────────────────────────────────────
function initTagFilters(containerSelector, callback) {
  const container = document.querySelector(containerSelector);
  if (!container) return;
  const tags = new Set();

  container.querySelectorAll('.tag-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const val = btn.dataset.value;
      if (tags.has(val)) { tags.delete(val); btn.classList.remove('active'); }
      else                { tags.add(val);    btn.classList.add('active'); }
      if (callback) callback([...tags]);
    });
  });
}

// ── FORM VALIDATION ──────────────────────────────────────────
function validateField(input) {
  const type = input.dataset.validate;
  const val  = input.value.trim();
  let   error = '';

  if (input.required && !val) {
    error = STRINGS[currentLang].required;
  } else if (type === 'email' && val && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(val)) {
    error = STRINGS[currentLang].invalid_email;
  } else if (type === 'zip' && val && !/^\d{5}$/.test(val)) {
    error = STRINGS[currentLang].invalid_zip;
  } else if (type === 'phone' && val && !/^[\d\s\(\)\-\+]{7,15}$/.test(val)) {
    error = STRINGS[currentLang].invalid_phone;
  }

  const errEl = input.parentElement.querySelector('.field-error');
  if (errEl) errEl.textContent = error;
  input.style.borderColor = error ? 'var(--coral)' : '';
  return !error;
}

function validateForm(formEl) {
  let valid = true;
  formEl.querySelectorAll('[required],[data-validate]').forEach(input => {
    if (!validateField(input)) valid = false;
  });
  return valid;
}

function initFormValidation(formEl) {
  if (!formEl) return;
  formEl.querySelectorAll('[required],[data-validate]').forEach(input => {
    input.addEventListener('blur', () => validateField(input));
    input.addEventListener('input', () => {
      if (input.style.borderColor) validateField(input); // re-validate if already errored
    });
  });
}

// ── NETLIFY FORM SUBMIT ──────────────────────────────────────
async function submitNetlifyForm(formEl, onSuccess, onError) {
  const btn = formEl.querySelector('[type=submit]');
  const origText = btn.textContent;
  btn.disabled = true;
  btn.textContent = STRINGS[currentLang].submitting;

  const data = new FormData(formEl);
  // Add dietary tags if present
  const activeTags = [...formEl.querySelectorAll('.tag-btn.active')].map(b => b.dataset.value);
  if (activeTags.length) data.set('dietary_needs', activeTags.join(', '));

  try {
    const res = await fetch('/', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams(data).toString()
    });
    if (res.ok) {
      onSuccess();
    } else {
      throw new Error('Non-OK response');
    }
  } catch (err) {
    btn.disabled = false;
    btn.textContent = origText;
    if (onError) onError();
    else showAlert(formEl, STRINGS[currentLang].submit_error, 'error');
  }
}

// ── MULTI-STEP FORM ──────────────────────────────────────────
function initMultiStep(formEl) {
  if (!formEl) return;
  const steps   = [...formEl.querySelectorAll('.form-step')];
  const circles = [...document.querySelectorAll('.step-circle')];
  const lines   = [...document.querySelectorAll('.step-line')];
  let   current = 0;

  function showStep(n) {
    steps.forEach((s, i) => s.classList.toggle('hidden', i !== n));
    circles.forEach((c, i) => {
      c.classList.toggle('active', i === n);
      c.classList.toggle('done',   i < n);
    });
    lines.forEach((l, i) => l.classList.toggle('done', i < n));
    current = n;
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  formEl.querySelectorAll('[data-next]').forEach(btn => {
    btn.addEventListener('click', () => {
      const stepEl = steps[current];
      const inputs = stepEl.querySelectorAll('[required],[data-validate]');
      let ok = true;
      inputs.forEach(inp => { if (!validateField(inp)) ok = false; });
      if (ok) showStep(current + 1);
    });
  });

  formEl.querySelectorAll('[data-back]').forEach(btn => {
    btn.addEventListener('click', () => showStep(current - 1));
  });

  showStep(0);
}

// ── ALERT HELPER ────────────────────────────────────────────
function showAlert(container, msg, type = 'info') {
  let el = container.querySelector('.form-alert');
  if (!el) { el = document.createElement('div'); el.className = 'alert form-alert'; container.prepend(el); }
  el.className = `alert alert-${type} form-alert`;
  el.textContent = msg;
  el.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

// ── RECIPE FILTER ────────────────────────────────────────────
function initRecipeFilter() {
  const grid = document.querySelector('.recipe-grid');
  if (!grid) return;

  document.querySelectorAll('[data-filter]').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('[data-filter]').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const filter = btn.dataset.filter;
      grid.querySelectorAll('.recipe-card').forEach(card => {
        const tags = card.dataset.tags || '';
        card.classList.toggle('hidden', filter !== 'all' && !tags.includes(filter));
      });
    });
  });
}

// ── INIT ────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  initLangToggle();
  initRecipeFilter();
});
